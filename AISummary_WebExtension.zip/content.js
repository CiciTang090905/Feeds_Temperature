// content.js (X / Twitter)
// Robust "current post" detection in virtualized timeline using hit-testing
// Strategy:
// 1) Determine a stable point (or several) inside the primary column
// 2) elementFromPoint -> closest(cellInnerDiv) -> tweet article
// 3) Extract tweetText by hit-testing inside the chosen cell/tweet

// ----------------------
// Generic fallback (non-X)
// ----------------------
function getArticleText() {
  const article = document.querySelector("article");
  if (article) return article.innerText;

  const paragraphs = Array.from(document.querySelectorAll("p"));
  return paragraphs.map((p) => p.innerText).join("\n");
}

// ----------------------
// Active intent tracking
// ----------------------
let activeCell = null;

function setActiveFromNode(node) {
  // Prefer cellInnerDiv as the unit of a "post in feed"
  const cell = node?.closest?.('div[data-testid="cellInnerDiv"]');
  if (cell) activeCell = cell;
}

document.addEventListener("pointerdown", (e) => setActiveFromNode(e.target), true);
document.addEventListener("focusin", (e) => setActiveFromNode(e.target), true);

// ----------------------
// Helpers: primary column + hit-testing
// ----------------------
function getPrimaryColumn() {
  return document.querySelector('div[data-testid="primaryColumn"]');
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

/**
 * Returns a small set of points inside the primary column.
 * Multi-sampling makes selection stable if one point hits a video overlay, etc.
 */
function getSamplingPoints() {
  const primary = getPrimaryColumn();
  if (!primary) return [];

  const r = primary.getBoundingClientRect();

  // Keep points away from edges (reduce hitting padding / borders)
  const xMid = r.left + r.width * 0.50;
  const xLeft = r.left + r.width * 0.30;
  const xRight = r.left + r.width * 0.70;

  // A bit below header; then mid; then slightly lower
  const yA = r.top + r.height * 0.32;
  const yB = r.top + r.height * 0.42;
  const yC = r.top + r.height * 0.52;

  const points = [
    { x: xMid, y: yA },
    { x: xLeft, y: yB },
    { x: xRight, y: yB },
    { x: xMid, y: yC },
  ];

  // Clamp to viewport
  return points.map((p) => ({
    x: Math.floor(clamp(p.x, 0, window.innerWidth - 1)),
    y: Math.floor(clamp(p.y, 0, window.innerHeight - 1)),
  }));
}

/**
 * Hit-test a point and return the feed cell (cellInnerDiv) at that point.
 */
function cellFromPoint(x, y) {
  const el = document.elementFromPoint(x, y);
  if (!el) return null;
  return el.closest?.('div[data-testid="cellInnerDiv"]') || null;
}

/**
 * Choose the best current cell:
 * 1) If user interacted with a cell recently and it's still in DOM, use it
 * 2) Otherwise, majority-vote among multiple hit-test sample points
 */
function findCurrentCell() {
  if (activeCell && activeCell.isConnected) return activeCell;

  const points = getSamplingPoints();
  if (!points.length) return null;

  const counts = new Map(); // cell -> votes

  for (const p of points) {
    const cell = cellFromPoint(p.x, p.y);
    if (!cell) continue;

    counts.set(cell, (counts.get(cell) || 0) + 1);
  }

  // Pick the cell with the most votes
  let best = null;
  let bestVotes = 0;
  for (const [cell, votes] of counts.entries()) {
    if (votes > bestVotes) {
      bestVotes = votes;
      best = cell;
    }
  }

  return best;
}

// ----------------------
// Extract tweet + tweetText robustly
// ----------------------
function findTweetInCell(cell) {
  if (!cell) return null;
  return cell.querySelector?.('article[data-testid="tweet"]') || null;
}

/**
 * Instead of "first tweetText", pick the tweetText that is actually at a sampling point.
 * This prevents selecting quoted/parent tweetText inside the same card.
 */
function pickTweetTextByHitTest(cell) {
  const points = getSamplingPoints();
  if (!points.length) return null;

  for (const p of points) {
    const el = document.elementFromPoint(p.x, p.y);
    if (!el) continue;

    // Ensure the point is inside the selected cell (important!)
    if (!cell.contains(el)) continue;

    const textNode = el.closest?.('div[data-testid="tweetText"]');
    if (textNode && cell.contains(textNode)) return textNode;
  }

  // Fallback: choose the tweetText with the largest visible area in viewport
  const textNodes = Array.from(cell.querySelectorAll('div[data-testid="tweetText"]'));
  if (!textNodes.length) return null;

  const vh = window.innerHeight;

  let best = null;
  let bestVisible = 0;
  for (const n of textNodes) {
    const r = n.getBoundingClientRect();
    const visibleTop = Math.max(r.top, 0);
    const visibleBottom = Math.min(r.bottom, vh);
    const visibleH = Math.max(0, visibleBottom - visibleTop);
    if (visibleH > bestVisible) {
      bestVisible = visibleH;
      best = n;
    }
  }

  return best || textNodes[0];
}

function getTweetTextFromCell(cell) {
  const node = pickTweetTextByHitTest(cell);
  return node ? node.innerText : "";
}

function getTweetStatsFromCell(cell) {
  // Stats are typically in div[role="group"][aria-label] inside the tweet card
  const group = cell.querySelector?.('div[role="group"][aria-label]');
  if (!group) return null;

  const label = group.getAttribute("aria-label");
  if (!label) return null;

  const stats = {};
  const regex = /([\d,.]+)\s+(repl(?:y|ies)|reposts?|likes?|bookmarks?|views?)/gi;

  let match;
  while ((match = regex.exec(label)) !== null) {
    const value = match[1].replace(/,/g, "");
    const metric = match[2].toLowerCase();

    if (metric.startsWith("repl")) stats.replies = value;
    else if (metric.startsWith("repost")) stats.reposts = value;
    else if (metric.startsWith("like")) stats.likes = value;
    else if (metric.startsWith("bookmark")) stats.bookmarks = value;
    else if (metric.startsWith("view")) stats.views = value;
  }

  return stats;
}

// ----------------------
// Public API for popup.js
// ----------------------
function isOnX() {
  return /(^|\.)x\.com$/.test(location.hostname) || /(^|\.)twitter\.com$/.test(location.hostname);
}

function getPageData() {
  if (!isOnX()) {
    return { kind: "article", text: getArticleText(), stats: null };
  }

  const cell = findCurrentCell();
  const tweet = findTweetInCell(cell);

  if (cell && tweet) {
    return {
      kind: "tweet",
      text: getTweetTextFromCell(cell),
      stats: getTweetStatsFromCell(cell),
    };
  }

  // Fallback if X selectors fail
  return { kind: "article", text: getArticleText(), stats: null };
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === "GET_PAGE_DATA") {
    sendResponse(getPageData());
    return true;
  }
});
